% Matlab file for_ paper "Solving Heterogeneous Agent Models by Projection and Perturbation"
% Michael Reiter, Institute for Advanced Studies, September 2006
% Last update: June 2008
% Feel free to use, copy and modify at your own risk;
%   this program comes with NO WARRANTY WHATSOEVER
% Function to interpolate cubic spline,
%   with extrapolation out of bounds that is suitable
%   for a savings function with liquidity constraint
% Inputs:
%   x:    vector of knot points of the spline
%   y:    function_ values at x
%   y2:   second derivative of funcion_ at x, as output from natcubspline()
%   x0:   vector of x-values where to interpolate
% Outputs: 
%   y0:   vector of function_ values at x0
%   dy0:  vector of derivatives of the function_ x0
% BEHAVIOR OUT OF BOUNDS:
%   If x0(i) is lower than x(1):
%     y0(i) = y(1); dy0(i) = 0
%   If x0(i) is bigger than x(end):
%     y0(i) = linear extrapolation at end_ of spline
%     dy0(i) = dy of spline at x(end)
%   AS REQUIRED BY APPROXIMATION OF SAVINGS FUNCTION!!
