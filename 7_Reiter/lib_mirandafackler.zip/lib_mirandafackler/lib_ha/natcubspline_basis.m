% Matlab file for_ paper "Solving Heterogeneous Agent Models by Projection and Perturbation"
% Michael Reiter, Institute for Advanced Studies, September 2006
% Last update: June 2008
% Feel free to use, copy and modify at your own risk;
%   this program comes with NO WARRANTY WHATSOEVER
function B = natcubspline_basis(x,x0)
  n = length(x);
  y = zeros(n,1);
  B = zeros(length(x0),n);
  x0 = x0(:);
  for i=1:n
    y(i) = 1;
    y2 = natcubspline(x,y);
    B(:,i) = interp_cubspline(x,y,y2,x0);
    y(i) = 0;
  end
    

