/* Matlab file for_ paper "Solving Heterogeneous Agent Models by Projection and Perturbation"
  Michael Reiter, Institute for Advanced Studies, September 2006
  Last update: June 2008
  Feel free to use, copy and modify at your own risk;
    this program comes with NO WARRANTY WHATSOEVER*/
void splint(const double xa[], const double ya[], const double y2a[], double x, int klo,
	    double *y, double *dy, double *ddy);
void huntfast(const double *xx, int n, double x, int *jlo);

#include "cfunc.h"


/* LEAVE THIS LINE ALWAYS UNCHANGED:  */
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{

  int i,n,n0;
  int jlo=1;
  double xa,xb,sb,dsb;
  char str[100];

  DECL_MAT(x);
  DECL_MAT(y);
  DECL_MAT(y2);
  DECL_MAT(x0);
  DECL_OUTPUT(y0);
  DECL_OUTPUT(dy0);

  if(nrhs!=4){
    sprintf(str,"4 inputs required"); mexErrMsgTxt(str);
  } 
  if(nlhs>2) {
    sprintf(str,"gives at most 2 outputs");mexErrMsgTxt(str);
  } 

  GET_ARG_MAT(x,1);
  GET_ARG_MAT(y,2);
  GET_ARG_MAT(y2,3);
  GET_ARG_MAT(x0,4);

  n = x_nr;
  assert(x_nc==1 && y_nc==1 && y_nr==n,"incompatible dimensions in interpolation");
  CREATE_OUTPUT(1,y0,x0_nr,x0_nc,REAL);
  CREATE_OUTPUT(2,dy0,x0_nr,x0_nc,REAL);

  n0 = x0_nr*x0_nc;
  xa = x[1];
  xb = x[n];
  sb = y[n];
  splint(x,y,y2,x[n],n-1,&sb,&dsb,0);
  for(i=1;i<=n0;i++){
    double xi = x0[i];
    if(xi<xa){
      y0[i] = y[1];
      dy0[i] = 0;
    } else if(xi>xb){
      y0[i] = sb + dsb*(xi-xb);
      dy0[i] = dsb;
    } else {
      huntfast(x, n, xi, &jlo);
      splint(x,y,y2,xi,jlo,&y0[i],&dy0[i],0);
    }
  }
}

