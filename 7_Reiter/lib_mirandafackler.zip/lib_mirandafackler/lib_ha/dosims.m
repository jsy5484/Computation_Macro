% Matlab file for_ paper "Solving Heterogeneous Agent Models by Projection and Perturbation"
% Michael Reiter, Institute for Advanced Studies, September 2006
% Last update: June 2008
% Feel free to use, copy and modify at your own risk;
%   this program comes with NO WARRANTY WHATSOEVER
function [G1,impact,eu,abseig] = dosims(funcequ,stst,ix,ixlag,ieps,ieta,varargin)

  ntotal = max([max(ix),max(ixlag),max(ieps),max(ieta)]);

  stst2 = zeros(ntotal,1);
  stst2([ixlag ix]) = repmat(stst,2,1);
  resid = feval(funcequ,stst2,varargin{:});
  check = max(abs(resid));
  if(check>1e-8)  % CHECK THAT RESIDUALS ARE VERY SMALL AT THE STEADY STATE!!;
    warning(sprintf('Maximum residual at stst is %e; press any key to continue',check));
    pause;  
  end;

  tic;
  jac = jacob(funcequ,stst2,1e-6,varargin{:});
  tjac = toc;
  fprintf(1,'Time used for Jacobian:  %f seconds\n',tjac);

  % SAME AS IN ALL OTHER APPLICATIONS:
  g0 = -jac(:,ix);
  g1 = jac(:,ixlag);
  c = zeros(size(g0,1),1);
  Psi = jac(:,ieps);
  Pi = jac(:,ieta);
  div = 1+1e-10;

  tic;
  [eu,eigvals,G1,impact] = checkeu(g0,g1,Psi,Pi,div);
  tsims = toc;
  fprintf(1,'Time used for solving the model:  %f seconds\n',tsims);
  abseig = flipud(sort(abs(eigvals)));
  return;


