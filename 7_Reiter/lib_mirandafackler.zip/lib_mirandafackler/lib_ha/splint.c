/* Matlab file for_ paper "Solving Heterogeneous Agent Models by Projection and Perturbation"
  Michael Reiter, Institute for Advanced Studies, September 2006
  Last update: June 2008
  Feel free to use, copy and modify at your own risk;
    this program comes with NO WARRANTY WHATSOEVER*/
void splint(const double xa[], const double ya[], const double y2a[], double x, int klo,
	    double *y, double *dy, double *ddy);

void splint(const double xa[], const double ya[], const double y2a[], double x, int klo,
	    double *y, double *dy, double *ddy)
{
  int k;
  double h,b,a,db,da,a2,b2,h6;

  int khi=klo+1;
  h=xa[khi]-xa[klo];
  /* assert(h,"Bad xa input to routine splint"); */
  a=(xa[khi]-x)/h;
  b=(x-xa[klo])/h;
  b2 = b*b;
  a2 = a*a;
  h6 = h*h/6;
  *y=a*ya[klo]+b*ya[khi]+((a*a2-a)*y2a[klo]+(b*b2-b)*y2a[khi])*h6;

  db = 1/h;
  da = -db;
  if(dy)
    *dy=  da*ya[klo]+db*ya[khi]
      +((3*a2*da-da)*y2a[klo]+(3*b2*db-db)*y2a[khi])*h6;
  
  if(ddy)
    *ddy= a*y2a[klo] + b*y2a[khi];

}
