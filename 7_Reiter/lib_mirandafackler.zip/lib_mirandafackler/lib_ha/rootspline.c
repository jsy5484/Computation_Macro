/* Matlab file for_ paper "Solving Heterogeneous Agent Models by Projection and Perturbation"
  Michael Reiter, Institute for Advanced Studies, September 2006
  Last update: June 2008
  Feel free to use, copy and modify at your own risk;
    this program comes with NO WARRANTY WHATSOEVER*/
void splint(const double xa[], const double ya[], const double y2a[], double x, int klo,
	    double *y, double *dy, double *ddy);
double splineroot(const double x[], const double y[], const double y2[], double y0, int j);
void huntfast(const double *xx, int n, double x, int *jlo);

#include "cfunc.h"


/* LEAVE THIS LINE ALWAYS UNCHANGED:  */
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{

  int i,n,n0;
  int jlo=1;
  double xb,sb,dsb;

  DECL_MAT(x);
  DECL_MAT(y);
  DECL_MAT(y2);
  DECL_MAT(ytarget);
  DECL_OUTPUT(x0);

  CHECK_ARGN(4,1);


  GET_ARG_MAT(x,1);
  GET_ARG_MAT(y,2);
  GET_ARG_MAT(y2,3);
  GET_ARG_MAT(ytarget,4);

  n = x_nr;
  assert(x_nc==1 && y_nc==1 && y_nr==n,"incompatible dimensions in interpolation");
  CREATE_OUTPUT(1,x0,ytarget_nr,ytarget_nc,REAL);


  n0 = ytarget_nr*ytarget_nc;
  xb = x[n];
  sb = y[n];
  splint(x,y,y2,x[n],n-1,&sb,&dsb,0);
  for(i=1;i<=n0;i++){
    double yi = ytarget[i];
    if(yi>=sb)
      x0[i] = xb + (yi-sb)/dsb;
    else if(yi==y[1])
      x0[i] = x[1];
    else {
      huntfast(y, n, yi, &jlo);
      x0[i] = splineroot(x,y,y2,yi,jlo);
    }
  }
}


double splineroot(const double x[], const double y[], const double y2[], double y0, int j)
{
  int i,j1=j+1;
  double fac=(y0-y[j])/(y[j1]-y[j]);
  double x0 = (1-fac)*x[j] + fac*x[j1];
  double xtol = (x[j1]-x[j])*1e-10;
  double aux,b,c,f,df,ddf,discr,dx;

  for(i=0;i<10;i++){
    splint(x,y,y2,x0,j,&f,&df,&ddf);
    /* APPLY HERE:
       fx = f + df*dx + 0.5*ddf*dx^2 
       ==>
       dx^2 + b*dx + c*dx^2 = 0
       where
       b = 2*df/ddf;
       c = 2*(f-fx)/ddf
       The solution 
       dx = -(b-sqrt(b^2-4c))/2
       is right if c approx 0!
  */
    aux = 2/ddf;
    b = df*aux;
    c = (f-y0)*aux;
    discr = 1-4*c/(b*b);
    if(discr<0){
      printf("ytarget = %e; f=%e, df=%e, d2f=%e\n",y0,f,df,ddf);
      assert(0,"quadr. approximation fails in rootspline.c");
    }
    dx = -0.5*b*(1-sqrt(discr));
#if 0
    /* use sqrt(discr)=1+0.5*(discr-1) */
    dx = 0.25*b*(discr-1);
#endif
    x0 += dx;
    /* printf("dx = %f\n",dx);  */
    if(fabs(dx)<xtol)
      break;
  }
     
  return x0;
  
  
}



