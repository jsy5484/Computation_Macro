/* Matlab file for_ paper "Solving Heterogeneous Agent Models by Projection and Perturbation"
  Michael Reiter, Institute for Advanced Studies, September 2006
  Last update: June 2008
  Feel free to use, copy and modify at your own risk;
    this program comes with NO WARRANTY WHATSOEVER*/
#include "cfunc.h"

void hunt(double xx[], int n, double x, int *jlo);

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{

  static int jlo=1;
  int i,n,nn;

  DECL_MAT(x);
  DECL_MAT(x0);
  /* DECLARE OUTPUT MATRICES: */
  DECL_OUTPUT(pos);

  /* FUNCTION GETS 2 INPUTS AND 1 OUTPUT ARGUMENT:  */
  CHECK_ARGN(2,1);


  GET_ARG_MAT(x,1);
  GET_ARG_MAT(x0,2);

  if(x_nc==1){
    n = x_nr;
  } else {
    assert(x_nr==1,"table in hunttable must be vector");
    n = x_nc;
  }
  nn = x0_nr*x0_nc;
  CREATE_OUTPUT(1,pos,x0_nr,x0_nc,REAL);

  for(i=1;i<=nn;i++){
    hunt(x,n,x0[i],&jlo);
    if(jlo==n && x0[i]==x[n])
      jlo = n-1;
    else if(jlo==0 && x0[i]==x[1])
      jlo = 1;
    pos[i] = jlo;
  }
}



void hunt(double xx[], int n, double x, int *jlo)
{
  int jm,jhi,inc;
  int ascnd;
  
  ascnd=(xx[n] > xx[1]);
  if (*jlo <= 0 || *jlo > n) {
    *jlo=0;
    jhi=n+1;
  } else {
    inc=1;
    if (x >= xx[*jlo] == ascnd) {
      if (*jlo == n) return;
      jhi=(*jlo)+1;
      while (x >= xx[jhi] == ascnd) {
	*jlo=jhi;
	inc += inc;
	jhi=(*jlo)+inc;
	if (jhi > n) {
	  jhi=n+1;
	  break;
	}
      }
    } else {
      if (*jlo == 1) {
	*jlo=0;
	return;
      }
      jhi=(*jlo)--;
      while (x < xx[*jlo] == ascnd) {
	jhi=(*jlo);
	inc <<= 1;
	if (inc >= jhi) {
	  *jlo=0;
	  break;
	}
	else *jlo=jhi-inc;
      }
    }
  }
  while (jhi-(*jlo) != 1) {
    jm=(jhi+(*jlo)) >> 1;
    if (x > xx[jm] == ascnd)
      *jlo=jm;
    else
      jhi=jm;
  }
}

