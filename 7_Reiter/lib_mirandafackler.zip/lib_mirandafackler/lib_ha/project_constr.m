% Matlab file for_ paper "Solving Heterogeneous Agent Models by Projection and Perturbation"
% Michael Reiter, Institute for Advanced Studies, September 2006
% Last update: June 2008
% Feel free to use, copy and modify at your own risk;
%   this program comes with NO WARRANTY WHATSOEVER
% Problem:
%  min_{beta} (y-B*beta)-(y-B*beta) 
%    s.t. M'y = M'B*beta
%  FOCs: B'(y-B*beta) = B'*M*lambda
function P = project_constr(B,M)

  nu = null(M'*B);
  A = [nu'*B'*B;
       M'*B];
  b = [nu'*B';
       M'];

  % A*beta = b*y
  P = inv(A)*b;