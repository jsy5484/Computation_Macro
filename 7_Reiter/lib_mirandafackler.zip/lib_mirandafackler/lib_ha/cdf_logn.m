% Matlab file for_ paper "Solving Heterogeneous Agent Models by Projection and Perturbation"
% Michael Reiter, Institute for Advanced Studies, September 2006
% Last update: June 2008
% Feel free to use, copy and modify at your own risk;
%   this program comes with NO WARRANTY WHATSOEVER
function c = cdf_logn(x, mu, stdev)
  ispos = x>0;
  c = zeros(size(x));
  % c = 0.5*(1+erf((x-mu)/sqrt(2)/stdev)); 
  c(ispos) = cdf_normal(log(x(ispos)),mu,stdev);


