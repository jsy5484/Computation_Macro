% Matlab file for_ paper "Solving Heterogeneous Agent Models by Projection and Perturbation"
% Michael Reiter, Institute for Advanced Studies, September 2006
% Last update: June 2008
% Feel free to use, copy and modify at your own risk;
%   this program comes with NO WARRANTY WHATSOEVER
% cumprob[n-1] must be 1, for safety;
% X and cumprob are unit-offset;
function [X,Xmax] = DiscreteApproxParetian(cumprob, C, gam)
  n = length(cumprob);
  theta = zeros(n+1,1);
  prob = zeros(n,1);
  X = zeros(n,1);

  theta(1) = quantile_paretian(0,C,gam);
  prob(1) = cumprob(1);
  for i=1:n-1
    theta(i+1) = quantile_paretian(cumprob(i),C,gam);
    prob(i+1) = cumprob(i+1)-cumprob(i);
  end
  if(cumprob(n)<1)
    warning(sprintf('Paretian truncated at %e',1-cumprob(n)));
    theta(n+1) = quantile_paretian(cumprob(n),C,gam);
  else
    theta(n+1) = 2e100;
  end
  for i=1:n
    assert(prob(i)>0,'wrong probs');
    X(i) =  CondExpectParetian(theta(i),theta(i+1),C,gam)/prob(i); % since CondProb = 1/n;
  end
  Xmax = theta(n+1);


function z = quantile_paretian(q, C, gam)
  z = (C/(1-q)).^(1/gam);


function z = CondExpectParetian(a, b, C, gam)
  fac = C*gam/(1-gam);
  if(b>=1e100)
    assert(C>0,'wrong C');
    assert(gam>1,'wrong gam');  %  otherwise expectation does not exist;
    z = -fac*a.^(1-gam);
  else 
    z = fac*(b.^(1-gam) - a.^(1-gam));
  end

function z = ExpectParetian(C, gam)
  a = quantile_paretian(0,C,gam);
  z =CondExpectParetian(a,2e100,C,gam);



