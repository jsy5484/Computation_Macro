% Matlab file for_ paper "Solving Heterogeneous Agent Models by Projection and Perturbation"
% Michael Reiter, Institute for Advanced Studies, September 2006
% Last update: June 2008
% Feel free to use, copy and modify at your own risk;
%   this program comes with NO WARRANTY WHATSOEVER
% Function to define Schumaker's quadratic spline
% Inputs:
%   x:    vector of knot points of the spline
%   y:    function_ values at x
%   dy:   function_ derivatives at x
% Outputs: 
%   xx:   augmented vector of knot points
%   yy:   function_ values at xx
%   dyy   function_ derivatives at xx
% The outputs are inputs to evalquadspline.m