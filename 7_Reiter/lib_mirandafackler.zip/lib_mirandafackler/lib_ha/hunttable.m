% Matlab file for_ paper "Solving Heterogeneous Agent Models by Projection and Perturbation"
% Michael Reiter, Institute for Advanced Studies, September 2006
% Last update: June 2008
% Feel free to use, copy and modify at your own risk;
%   this program comes with NO WARRANTY WHATSOEVER
% Table lookup
% Inputs:
%   x:   vector of x values, in ascending or descending order
%   x0:  vector of values whose position in x has to be found
% Outputs
%   pos:  vector of indices such that x(pos)<=x0 and x(pos+1)>x0
% BEHAVIOR OUT OF BOUNDS:
%   if x0(i) < x(1)
%      pos(i) = 0
%   if x0(i) > x(end)
%      pos(i) = n (length of x)
%   if x0(i) == x(end)
%      pos(i) = n-1

