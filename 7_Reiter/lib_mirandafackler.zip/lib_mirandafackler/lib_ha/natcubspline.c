/* Matlab file for_ paper "Solving Heterogeneous Agent Models by Projection and Perturbation"
  Michael Reiter, Institute for Advanced Studies, September 2006
  Last update: June 2008
  Feel free to use, copy and modify at your own risk;
    this program comes with NO WARRANTY WHATSOEVER*/
void spline(const double x[], const double y[], int n, double yp1, double ypn, double y2[]);


#include "cfunc.h"


/* LEAVE THIS LINE ALWAYS UNCHANGED:  */
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{

  int n;
  double d2ya, d2yb;
  DECL_MAT(x);
  DECL_MAT(y);
  DECL_OUTPUT(y2);

  /* CHECK_ARGN(2,1); */


  GET_ARG_MAT(x,1);
  GET_ARG_MAT(y,2);

  if(nrhs>=3)
    d2ya = GET_ARG_SCALAR(3);
  else
    d2ya = 1e100;
  if(nrhs>=4)
    d2yb = GET_ARG_SCALAR(4);
  else
    d2yb = 1e100;

  n = x_nr;
  assert(x_nc==1 && y_nc==1 && y_nr==n,"incompatible dimensions in interpolation");
  CREATE_OUTPUT(1,y2,n,1,REAL);
  spline(x,y,n,d2ya,d2yb,y2);
}




#define NR_END 0
double *dvector(long nl, long nh)
/* allocate a double vector with subscript range v[nl..nh] */
{
	double *v;

	v=(double *)malloc((size_t) ((nh-nl+1+NR_END)*sizeof(double)));
	assert (v,"allocation failure in dvector");
	return v-nl+NR_END;
}

void free_dvector(double *v, long nl, long nh)
/* free a double vector allocated with dvector() */
{
	free( (v+nl-NR_END));
}


void spline(const double x[], const double y[], int n, double yp1, double ypn, double y2[])
{
  int i,k;
  double p,qn,sig,un,*u;
  
  u=dvector(1,n-1);
  if (yp1 > 0.99e30)
    y2[1]=u[1]=0.0;
  else {
    y2[1] = -0.5;
    u[1]=(3.0/(x[2]-x[1]))*((y[2]-y[1])/(x[2]-x[1])-yp1);
  }
  for (i=2;i<=n-1;i++) {
    sig=(x[i]-x[i-1])/(x[i+1]-x[i-1]);
    p=sig*y2[i-1]+2.0;
    y2[i]=(sig-1.0)/p;
    u[i]=(y[i+1]-y[i])/(x[i+1]-x[i]) - (y[i]-y[i-1])/(x[i]-x[i-1]);
    u[i]=(6.0*u[i]/(x[i+1]-x[i-1])-sig*u[i-1])/p;
  }
  if (ypn > 0.99e30)
    qn=un=0.0;
  else {
    qn=0.5;
    un=(3.0/(x[n]-x[n-1]))*(ypn-(y[n]-y[n-1])/(x[n]-x[n-1]));
  }
  y2[n]=(un-qn*u[n-1])/(qn*y2[n-1]+1.0);
  for (k=n-1;k>=1;k--)
    y2[k]=y2[k]*y2[k+1]+u[k];
  free_dvector(u,1,n-1);
}
