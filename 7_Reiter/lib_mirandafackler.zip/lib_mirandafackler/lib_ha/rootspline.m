% Matlab file for_ paper "Solving Heterogeneous Agent Models by Projection and Perturbation"
% Michael Reiter, Institute for Advanced Studies, September 2006
% Last update: June 2008
% Feel free to use, copy and modify at your own risk;
%   this program comes with NO WARRANTY WHATSOEVER
% "Inverse interpolation" of cubic spline
% Inputs:
%   x:    vector of knot points of the spline
%   y:    function_ values at x
%   y2:   second derivative of funcion_ at x, as output from natcubspline()
%   y0:   vector of y-values to which_ x0 has to be found
% Outputs: 
%   x0:   vector of x-values at which function_ values is y0
%   dy0:   vector of function_ derivatives at x0
%  BEHAVIOR OUT OF BOUNDS:
% If y0(i) is lower than y(1):
%   UNDEFINED
% If y0(i) is bigger than y(end):
%   x0(i) = by linear extrapolation at end_ of spline
%   dy0(i) = dy of spline at x(end)

