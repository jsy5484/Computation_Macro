% Matlab file for_ paper "Solving Heterogeneous Agent Models by Projection and Perturbation"
% Michael Reiter, Institute for Advanced Studies, September 2006
% Last update: June 2008
% Feel free to use, copy and modify at your own risk;
%   this program comes with NO WARRANTY WHATSOEVER
function s = compact_scientific(s)
  s = strrep(s,'e+0','e+');
  s = strrep(s,'e+0','e+');
  s = strrep(s,'e-0','e-');
  s = strrep(s,'e-0','e-');
