% Matlab file for_ paper "Solving Heterogeneous Agent Models by Projection and Perturbation"
% Michael Reiter, Institute for Advanced Studies, September 2006
% Last update: June 2008
% Feel free to use, copy and modify at your own risk;
%   this program comes with NO WARRANTY WHATSOEVER
function p = PDFNormal(x, mu, stdev)

  fac = 1 / (stdev*sqrt(2*acos(-1)));
  p = fac*exp(-(x-mu).^2/(2*stdev*stdev));

