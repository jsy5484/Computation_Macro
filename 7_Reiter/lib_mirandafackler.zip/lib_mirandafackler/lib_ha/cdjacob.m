% Matlab file for_ paper "Solving Heterogeneous Agent Models by Projection and Perturbation"
% Michael Reiter, Institute for Advanced Studies, September 2006
% Last update: June 2008
% Feel free to use, copy and modify at your own risk;
%   this program comes with NO WARRANTY WHATSOEVER
% computes Jacobian by forward differences
% Input:
% func: string, name of function
% x: point at which to take Jacobian
%    if function value at x is already known, then give x={starting point, function value}
% step: scalar, relative stepwidth;
% more arguments will be passed on to the function;
%
function jac = cdjacob(func,x0,step,varargin);
  n = size(x0,1);
  for i=1:n
    step2 = step*max(1,abs(x0(i)));
    x = x0;
    x(i) = x0(i) - step2;
    f0 = feval(func,x,varargin{:});
    if(i==1)
      m = size(f0,1);
      jac = zeros(m,n);      
    end
    x(i) = x0(i) + step2;
    f1 = feval(func,x,varargin{:});
    jac(1:m,i) = (f1-f0)/(2*step2);
  end;
