% Matlab file for_ paper "Solving Heterogeneous Agent Models by Projection and Perturbation"
% Michael Reiter, Institute for Advanced Studies, September 2006
% Last update: June 2008
% Feel free to use, copy and modify at your own risk;
%   this program comes with NO WARRANTY WHATSOEVER
function assert(cond,txt)
  if(~cond)
    if(nargin<2)
      txt = 'assertion wrong';
    end;
    error(txt);
  end;