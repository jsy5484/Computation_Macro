/* Matlab file for_ paper "Solving Heterogeneous Agent Models by Projection and Perturbation"
  Michael Reiter, Institute for Advanced Studies, September 2006
  Last update: June 2008
  Feel free to use, copy and modify at your own risk;
    this program comes with NO WARRANTY WHATSOEVER*/
#include "cfunc.h"

double PolyEval3PDD(/*double *deriv, */
		    double x, double  a, double  va, double  dva, 
		    double   b, double  dvb);
void schum_prep(double *xc, double *dvc, double xa, double xb, double va, double vb, double dva, double dvb);


void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{

  int i,n,n2;

  DECL_MAT(x);
  DECL_MAT(v);
  DECL_MAT(dv);
  /* DECLARE OUTPUT MATRICES: */
  DECL_OUTPUT(x2);
  DECL_OUTPUT(v2);
  DECL_OUTPUT(dv2);

  /* FUNCTION GETS 3 INPUTS AND 3 OUTPUT ARGUMENT:  */
  CHECK_ARGN(3,3);


  GET_ARG_MAT(x,1);
  GET_ARG_MAT(v,2);
  GET_ARG_MAT(dv,3);

  n = x_nr;
  n2 = 2*(n-1)+1;
  assert(n==v_nr && n==dv_nr && x_nc==1 && v_nc==1 && dv_nc==1,"wrong inputs to schumaker_convex");
  
  CREATE_OUTPUT(1,x2,n2,1,REAL);
  CREATE_OUTPUT(2,v2,n2,1,REAL);
  CREATE_OUTPUT(3,dv2,n2,1,REAL);

  for(i=1;i<n;i++){
    double xc,dvc;
    int i2 = 2*(i-1)+1;
    x2[i2] = x[i];
    x2[i2+2] = x[i+1];
    v2[i2] = v[i];
    v2[i2+2] = v[i+1];
    dv2[i2] = dv[i];
    dv2[i2+2] = dv[i+1];
    schum_prep(&xc,&dvc,x[i],x[i+1],v[i],v[i+1],dv[i],dv[i+1]);
    x2[i2+1] = xc;
    dv2[i2+1] = dvc;
    v2[i2+1] = PolyEval3PDD(xc,x[i],v[i],dv[i],xc,dvc);
  }
}

  
double PolyEval3PDD(/*double *deriv, */
		    double x, double  a, double  va, double  dva, 
		    double   b, double  dvb)
{
  int i;
  double d2va,d2vad,d,v;
  d2va = (dvb-dva)/(b-a);
  d = x-a;
  d2vad = d2va*d;
  /* *deriv = dva + d2vad;*/
  v = va + d*(dva + 0.5*d2vad);
  return v;
}


void schum_prep(double *xc, double *dvc, double xa, double xb, double va, double vb, double dva, double dvb)
{
  double dvmean = (vb-va)/(xb-xa);

  /* exactly satisfies quadratic equation; */
  /* monotonicity and concavity satisfied, if in the data; */
  int iexact = (dva+dvb) == 2*dvmean;
  if(iexact){
    *xc = xb;
    *dvc = dvb;
  } else {
    double t;
    *xc = (vb - dvb*xb - va + dva*xa) / (dva - dvb);
    if(! (*xc>xa && *xc<xb) ){  /* handles case of NaN */
      if(fabs(dva-dvmean)<1e-11 && fabs(dvb-dvmean)<1e-11){
	*xc = 0.5*(xa+xb);
	*dvc = dvmean;
	return;
      } else {
	assert(0,"function not strictly convex or concave");
      }
    }
    t = (*xc-xa)/(xb-xa);
    *dvc = 2*dvmean - t*dva - (1-t)*dvb;
  }
}
