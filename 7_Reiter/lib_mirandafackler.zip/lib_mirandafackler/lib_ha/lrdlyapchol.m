% Matlab file for_ paper "Solving Heterogeneous Agent Models by Projection and Perturbation"
% Michael Reiter, Institute for Advanced Studies, September 2006
% Last update: June 2008
% Feel free to use, copy and modify at your own risk;
%   this program comes with NO WARRANTY WHATSOEVER
function R = lrdlyapchol(A, B, nb)
%LRLYAPCHOL  Square-root solver for discrete-time Lyapunov equations.
%
%   R = LRLYAPCHOL(A,B) computes a Cholesky factorization X = R'*R of
%   the solution X to the Lyapunov matrix equation:
%
%       A*X*A'- X + B*B' = 0.
%
%   The matrix A must be square and d-stable, i.e., all eigenvalues must
%   lie in the open unit disk.
%
%   See also DLYAPCHOL, LYAPCHOL, LRLYAPCHOL.

ni = nargin;
error(nargchk(2,3,ni))
if ~isnumeric(A) || ~isnumeric(B) || ~isreal(A) || ~isreal(B)
   error('LRDLYAPCHOL expects real double arrays as inputs.')
end
n = size(A,1);
if n ~= size(A,2),
   error('A must be square.')
end
m = size(B,2);
if n ~= size(B,1),
   error('Dimensions of A and B do not match.')
end

if nargin < 3,
    % insert a handwaving value for block size
    nb = 48;
end

% balance
C = B';
[D,A] = balance(A'); 
C = C * D;
[Q,A] = schur(A);
C = C*Q;

R = lrlyap_mex(3,A,C,nb);
R = ( R * Q' ) / D;
