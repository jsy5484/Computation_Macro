% Matlab file for_ paper "Solving Heterogeneous Agent Models by Projection and Perturbation"
% Michael Reiter, Institute for Advanced Studies, September 2006
% Last update: June 2008
% Feel free to use, copy and modify at your own risk;
%   this program comes with NO WARRANTY WHATSOEVER
mex interp_cubspline.c splint.c huntfast.c
mex rootspline.c splint.c huntfast.c
mex natcubspline.c
mex schumaker_convex.c
mex hunttable.c
