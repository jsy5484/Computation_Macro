% Matlab file for_ paper "Solving Heterogeneous Agent Models by Projection and Perturbation"
% Michael Reiter, Institute for Advanced Studies, September 2006
% Last update: June 2008
% Feel free to use, copy and modify at your own risk;
%   this program comes with NO WARRANTY WHATSOEVER
% Function to define natural cubic spline
% Inputs:
%   x:    vector of knot points of the spline
%   y:    function_ values at x
% Outputs: 
%   y2:   second derivative of funcion_, input needed for_ interp_cubspline;
